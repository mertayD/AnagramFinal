package com.example.mertaydayanc.anagram;

import java.util.Random;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import java.util.Timer;
import java.util.TimerTask;


public class game extends AppCompatActivity implements View.OnClickListener {
    // if option 1, pick random from fourWords
    private  String[] fourWords = { "m", "a", "z", "e" };

    private String wordsInFour = "maze mae ae am em ma me za" ;

    private String[] fiveWords = { "d", "o", "z", "e", "d" };

    private String wordsInFive = "dozed doze eddo doe odd ode zed dedo ed od oe" ;

    private String[] sixWords = { "h", "i", "j", "a", "c", "k" };

    private String wordsInSix =  "hijack chai chia hack haik haji hick jack ahi chi haj hic " +
            "ich ick khi ah ai ha hi ka ki" ;

    private String[] sevenWords = { "z", "a", "p", "p", "e", "r", "s" };

    private String wordsInSeven = "zappers papers sapper zapper apers apres asper paper pares " +
            "parse pears perps prase preps presa rapes razes reaps repps spare spear aper apes " +
            "apps apse ares arse ears eras paps pare pars pase pear peas peps perp prep prez " +
            "rape raps rase rasp raze reap repp reps sear sera spae spar spaz zaps zeps ape " +
            "app are ars asp ear era ers pap par pas pea pep per pes rap ras rep res sae sap " +
            "sea ser spa zap zas zep";

    private String[] eightWords = { "q", "u", "i", "n", "c", "u", "n", "x" };

    private String wordsInEight = "quincunx quin unci inn nix nun in nu qi un xi xu";


    // words the user found
    private int foundWords;

    // words that can be found
    private int validWords;

    // constants for point values
    private static int TWO_LETTER = 5;

    private static int THREE_LETTER = 10;

    private static int FOUR_LETTER = 15;

    private static int FIVE_LETTER = 20;

    private static int SIX_LETTER = 25;

    private static int SEVEN_LETTER = 30;

    private static int EIGHT_LETTER = 35;

    // multiplies the points per letter by the selected dificulty level
    private int pointMult;

    // total of points
    private int pointTotal;

    Button button1;

    Button button2;

    Button button3;

    Button button4;

    Button button5;

    Button button6;

    Button button7;

    Button button8;

    Button buttonCheck;


    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        result = (TextView) findViewById(R.id.tv_result);
        final Intent thisActivity = getIntent();
        button1 = findViewById( R.id.b_letter1 );

        button2 =findViewById( R.id.b_letter2 );

        button3 =findViewById( R.id.b_letter3 );

        button4 =findViewById( R.id.b_letter4 );

        button5 =findViewById( R.id.b_letter5 );

        button6 =findViewById( R.id.b_letter6 );

        button7 =findViewById( R.id.b_letter7 );

        button8 =findViewById( R.id.b_letter8 );

        buttonCheck = findViewById( R.id.b_check );

        button1.setOnClickListener(this);

        button2.setOnClickListener(this);

        button3.setOnClickListener(this);

        button4.setOnClickListener(this);

        button5.setOnClickListener(this);

        button6.setOnClickListener(this);

        button7.setOnClickListener(this);

        button8.setOnClickListener(this);

        buttonCheck.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                check();
                clear();
            }
        });

        String length = "";

        if(thisActivity.hasExtra("LENGTH"))
        {
            length = thisActivity.getStringExtra("LENGTH");
            result.setText(length);
        }

        switch( length )
        {
            case "4":
                setButton( randomizeArray(), 4 );

                break;

            case "5":
                setButton( randomizeArray(), 5 );

                break;

            case "6":
                setButton( randomizeArray(), 6 );

                break;

            case "7":
                setButton( randomizeArray(), 7 );

                break;

            case "8":
                setButton( randomizeArray(), 8 );

                break;
        }


        new CountDownTimer(10000, 1000) {

            public void onTick(long millisUntilFinished) {
                result.setText("seconds remaining: " + millisUntilFinished / 1000);
            }

            public void onFinish() {
                AlertDialog.Builder builder = new AlertDialog.Builder(game.this);
                // Get the layout inflater
                LayoutInflater inflater = getLayoutInflater();

                builder.setView(inflater.inflate(R.layout.popup, null))
                        // Add action buttons
                        .setPositiveButton("TryAgain!", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                finish();
                                startActivity(thisActivity);
                            }
                        })
                        .setNegativeButton("GoHome!", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                finish();
                            }
                        });
                Dialog myDialog = builder.create();
                myDialog.show();
            }
        }.start();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.challengemenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int selectedItem = item.getItemId();
        if(selectedItem == R.id.b_back_main);
        {
            finish();
            return true;
        }
    }

    /*
    public void createPpoup(final Intent activity)
    {
        LayoutInflater inflater = getLayoutInflater();
        View popupView = inflater.inflate(R.layout.popup, null);

        int width = LinearLayout.LayoutParams.MATCH_PARENT;
        int height = LinearLayout.LayoutParams.MATCH_PARENT;


        boolean focusable = true; // lets taps outside the popup also dismiss it
        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);

        popupWindow.showAtLocation( findViewById(R.id.rl_game) , Gravity.CENTER, 0, 0);

        Button tryAgain =(Button)findViewById(R.id.b_tryAgain);
        Button home = (Button) findViewById(R.id.b_goHome);

        tryAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                startActivity(activity);
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    */

    private void setButton( String[] array, int buttonAmount )
    {
        switch( buttonAmount )
        {
            case 4:
                button1.setText(array[0]);

                button2.setText(array[1]);

                button3.setText(array[2]);

                button4.setText(array[3]);

                toggleVisibility( buttonAmount );

                break;

            case 5:
                break;
            case 6:
                break;
            case 7:
                break;
            case 8:
                break;
        }

    }

    private  String[] randomizeArray()
    {
        Random rand = new Random();

        int length = fourWords.length;

        for( int iter = length - 1; iter > 0; iter-- )
        {
            int position = rand.nextInt( iter );

            String temp = fourWords[ iter ];

            fourWords[ iter ] = fourWords[ position ];

            fourWords[ position ] = temp;
        }


        return fourWords;
    }

    private void toggleVisibility(int numberOfButtons)
    {
        switch( numberOfButtons )
        {
            case 4:
                button5.setVisibility(View.INVISIBLE);

                button6.setVisibility(View.INVISIBLE);

                button7.setVisibility(View.INVISIBLE);

                button8.setVisibility(View.INVISIBLE);

                break;

            case 5:
                button5.setVisibility(View.INVISIBLE);

                button7.setVisibility(View.INVISIBLE);

                button8.setVisibility(View.INVISIBLE);

                break;
            case 6:
                button5.setVisibility(View.INVISIBLE);

                button8.setVisibility(View.INVISIBLE);

                break;
            case 7:

                button8.setVisibility(View.INVISIBLE);

                break;
            case 8:
                break;
        }
    }

    private void clear()
    {

    }

    private void check()
    {

    }
    @Override
    public void onClick(View v)
    {

    }




}
