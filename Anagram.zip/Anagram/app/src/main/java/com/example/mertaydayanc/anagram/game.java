package com.example.mertaydayanc.anagram;

import java.util.Dictionary;
import java.util.Random;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.TextView;
import java.util.Timer;
import java.util.TimerTask;

import static android.graphics.drawable.Drawable.createFromPath;

public class game extends AppCompatActivity implements View.OnClickListener{
    // if option 1, pick random from fourWords
    private  String[] fourWords = { "m", "a", "z", "e" };

    private String wordsInFour = "maze mae ae am em ma me za" ;

    private String[] fiveWords = { "d", "o", "z", "e", "d" };

    private String wordsInFive = "dozed doze eddo doe odd ode zed dedo ed od oe" ;

    private String[] sixWords = { "h", "i", "j", "a", "c", "k" };

    private String wordsInSix =  "hijack chai chia hack haik haji hick jack ahi chi haj hic " +
            "ich ick khi ah ai ha hi ka ki" ;

    private String[] sevenWords = { "z", "a", "p", "p", "e", "r", "s" };

    private String wordsInSeven = "zappers papers sapper zapper apers apres asper paper pares " +
            "parse pears perps prase preps presa rapes razes reaps repps spare spear aper apes " +
            "apps apse ares arse ears eras paps pare pars pase pear peas peps perp prep prez " +
            "rape raps rase rasp raze reap repp reps sear sera spae spar spaz zaps zeps ape " +
            "app are ars asp ear era ers pap par pas pea pep per pes rap ras rep res sae sap " +
            "sea ser spa zap zas zep";

    private String[] eightWords = { "q", "u", "i", "n", "c", "u", "n", "x" };

    private String wordsInEight = "quincunx quin unci inn nix nun in nu qi un xi xu";


    // words the user found
    private int foundWords;

    // words that can be found
    private int validWords;

    // multiplies the points per letter by the selected dificulty level
    private int pointMult;

    // total of points
    private int pointTotal;

    private boolean checkisClicked = false;

    Button button1;

    Button button2;

    Button button3;

    Button button4;

    Button button5;

    Button button6;

    Button button7;

    Button button8;

    Button buttonCheck;

    Button[] buttonArray;// = {button1, button2, button3, button4, button5, button6, button7, button8};

    private int arraySize;

    private int barSize;

    ProgressBar pointsProgress;

    TextView result;

    TextView timerText;

    Button hint1;
    Button hint2;
    Button hint3;
    Button hint4;

    ImageView hint1_view;
    ImageView hint2_view;
    ImageView hint3_view;
    ImageView hint4_view;


    boolean backPressed = false;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_game);

        //pointsProgress = findViewById(R.id.progress);

        result = (TextView) findViewById(R.id.tv_result);

        result.setTextSize(Settings.fontSize);

        timerText = findViewById(R.id.timerText);
        timerText.setTextSize(Settings.fontSize);

        final Intent thisActivity = getIntent();

        button1 = findViewById( R.id.b_letter1 );
        button1.setTextSize(Settings.fontSize);

        button2 =findViewById( R.id.b_letter2 );
        button2.setTextSize(Settings.fontSize);

        button3 =findViewById( R.id.b_letter3 );
        button3.setTextSize(Settings.fontSize);

        button4 =findViewById( R.id.b_letter4 );
        button4.setTextSize(Settings.fontSize);

        button5 =findViewById( R.id.b_letter5 );
        button5.setTextSize(Settings.fontSize);

        button6 =findViewById( R.id.b_letter6 );
        button6.setTextSize(Settings.fontSize);

        button7 =findViewById( R.id.b_letter7 );
        button7.setTextSize(Settings.fontSize);

        button8 =findViewById( R.id.b_letter8 );
        button8.setTextSize(Settings.fontSize);


        hint1 = findViewById(R.id.b_hint1);
        hint1.setTextSize(Settings.fontSize);
        hint2 = findViewById(R.id.b_hint2);
        hint2.setTextSize(Settings.fontSize);
        hint3 = findViewById(R.id.b_hint3);
        hint3.setTextSize(Settings.fontSize);
        hint4 = findViewById(R.id.b_hint4);
        hint4.setTextSize(Settings.fontSize);
        buttonCheck = findViewById( R.id.b_check );
        buttonCheck.setTextSize(Settings.fontSize);

        hint1_view = (ImageView) findViewById(R.id.iv_hint_1);
        hint2_view = (ImageView) findViewById(R.id.iv_hint_2);
        hint3_view = (ImageView) findViewById(R.id.iv_hint_3);
        hint4_view = (ImageView) findViewById(R.id.iv_hint_4);

        String length = "0";

        if(thisActivity.hasExtra("LENGTH"))
        {
            length = thisActivity.getStringExtra("LENGTH");
        }
// need to add a points and possible points to the popup.

        arraySize = Integer.parseInt(length);

        buttonArray = new Button[8];

        barSize = Integer.parseInt(length);

       // setMaxProgress( Integer.parseInt(length) );
        Drawable gram =getResources().getDrawable( R.drawable.gram );
        Drawable man = getResources().getDrawable( R.drawable.man);
        Drawable ram = getResources().getDrawable( R.drawable.ram);
        Drawable rag = getResources().getDrawable( R.drawable.rag);
        Drawable nike = getResources().getDrawable( R.drawable.nike);
        Drawable odd = getResources().getDrawable( R.drawable.odd);
        Drawable doze = getResources().getDrawable( R.drawable.doze);
        Drawable zed = getResources().getDrawable( R.drawable.zed);
       switch( length )
       {
           case "4":
               setButton( randomizeArray(4), 4 );
               hint1_view.setImageDrawable(gram);
               hint2_view.setImageDrawable(man);
               hint3_view.setImageDrawable(rag);
               hint4_view.setImageDrawable(ram);
               break;

           case "5":
               setButton( randomizeArray(5), 5 );

               hint1_view.setImageDrawable(nike);
               hint2_view.setImageDrawable(doze);
               hint3_view.setImageDrawable(zed);
               hint4_view.setImageDrawable(odd);
               break;

           case "6":
               setButton( randomizeArray(6), 6 );

               break;

           case "7":
               setButton( randomizeArray(7), 7 );

               break;

           case "8":
               setButton( randomizeArray(8), 8 );

               break;
       }

        button1.setOnClickListener(this);

        button2.setOnClickListener(this);

        button3.setOnClickListener(this);

        button4.setOnClickListener(this);

        button5.setOnClickListener(this);

        button6.setOnClickListener(this);

        button7.setOnClickListener(this);

        button8.setOnClickListener(this);

        buttonArray[0] = button1;

        buttonArray[1] = button2;

        buttonArray[2] = button3;

        buttonArray[3] = button4;

        buttonArray[4] = button5;

        buttonArray[5] = button6;

        buttonArray[6] = button7;

        buttonArray[7] = button8;
// TODO use drawable class to add image resource onclick
        buttonCheck.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                checkisClicked = true;

                check();

                clear();
            }
        });
//TODO not working, something having to do with invisible objects not being clickable
        //even with clickable and fousable atributes set to true
        hint1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hint1.setVisibility(View.INVISIBLE);
                hint1_view.setVisibility(View.VISIBLE);

              pointTotal -= 10;
            }
        });
        hint2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hint2.setVisibility(View.INVISIBLE);
                hint2_view.setVisibility(View.VISIBLE);

                pointTotal -= 10;
            }
        });
        hint3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hint3.setVisibility(View.INVISIBLE);
                hint3_view.setVisibility(View.VISIBLE);

                pointTotal -= 10;
            }
        });
        hint4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hint4.setVisibility(View.INVISIBLE);
                hint4_view.setVisibility(View.VISIBLE);

                pointTotal -= 10;
            }
        });

//TODO add points to progress bar and stop crashes
     new CountDownTimer(10000, 1000) {

        public void onTick(long millisUntilFinished) {
            if(!backPressed)
                timerText.setText( Long.toString(millisUntilFinished / 1000));
        }

        public void onFinish() {
            if(!backPressed) {
                LeaderBoard.updateArr(30);
                LeaderBoard.updateArr(20);
                LeaderBoard.updateArr(10);
                LeaderBoard.updateArr(130);

                AlertDialog.Builder builder = new AlertDialog.Builder(game.this);
                // Get the layout inflater
                LayoutInflater inflater = getLayoutInflater();
                builder.setView(inflater.inflate(R.layout.popup, null))


                        // Add action buttons
                        .setPositiveButton("Try Again!", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                deductPoints();
                                finish();
                                startActivity(thisActivity);
                            }
                        })
                        .setNegativeButton("Go Home!", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                finish();
                            }
                        });
                pointsProgress = findViewById(R.id.progress);
                //setMaxProgress( barSize );
                //pointsProgress.incrementProgressBy(pointTotal);
                Dialog myDialog = builder.create();
                myDialog.show();
            }
        }
    }.start();

}


    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.challengemenu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int selectedItem = item.getItemId();

        if(selectedItem == R.id.b_back_main);
        {
            backPressed = true;
            finish();

            return true;
        }
    }



    private void setButton( String[] array, int buttonAmount )
    {
        //TODO change to work off of arraySze variabe; only append up to size?
        switch( buttonAmount )
        {
            case 4:
                button1.setText(array[0]);

                button2.setText(array[1]);

                button3.setText(array[2]);

                button4.setText(array[3]);

                toggleVisibility( buttonAmount );

                break;

            case 5:
                button1.setText(array[0]);

                button2.setText(array[1]);

                button3.setText(array[2]);

                button4.setText(array[3]);

                button6.setText(array[4]);

                toggleVisibility( buttonAmount );

                break;
            case 6:
                button1.setText(array[0]);

                button2.setText(array[1]);

                button3.setText(array[2]);

                button4.setText(array[3]);

                button6.setText(array[4]);

                button7.setText(array[5]);

                toggleVisibility( buttonAmount );

                break;

            case 7:
                button1.setText(array[0]);

                button2.setText(array[1]);

                button3.setText(array[2]);

                button4.setText(array[3]);

                button5.setText(array[4]);

                button6.setText(array[5]);

                button7.setText(array[6]);

                toggleVisibility( buttonAmount );

                break;

            case 8:
                button1.setText(array[0]);

                button2.setText(array[1]);

                button3.setText(array[2]);

                button4.setText(array[3]);

                button5.setText(array[4]);

                button6.setText(array[5]);

                button7.setText(array[6]);

                button8.setText(array[7]);

                toggleVisibility( buttonAmount );

                break;
        }

    }

    private  String[] randomizeArray(int buttonAmount)
    {
        Random rand = new Random();

        if( buttonAmount == 4 )
        {
            int length = fourWords.length;

            for( int iter = length - 1; iter > 0; iter-- )
            {
                int position = rand.nextInt( iter );

                String temp = fourWords[ iter ];

                fourWords[ iter ] = fourWords[ position ];

                fourWords[ position ] = temp;
            }

            return fourWords;
        }

        else if( buttonAmount == 5 )
        {
            int length = fiveWords.length;

            for( int iter = length - 1; iter > 0; iter-- )
            {
                int position = rand.nextInt( iter );

                String temp = fiveWords[ iter ];

                fiveWords[ iter ] = fiveWords[ position ];

                fiveWords[ position ] = temp;
            }

            return fiveWords;
        }

        else if( buttonAmount == 6 )
        {
            int length = sixWords.length;

            for( int iter = length - 1; iter > 0; iter-- )
            {
                int position = rand.nextInt( iter );

                String temp = sixWords[ iter ];

                sixWords[ iter ] = sixWords[ position ];

                sixWords[ position ] = temp;
            }

            return sixWords;
        }

        else if( buttonAmount == 7 )
        {
            int length = sevenWords.length;

            for( int iter = length - 1; iter > 0; iter-- )
            {
                int position = rand.nextInt( iter );

                String temp = sevenWords[ iter ];

                sevenWords[ iter ] = sevenWords[ position ];

                sevenWords[ position ] = temp;
            }

            return sevenWords;
        }

        else
        {
            int length = eightWords.length;

            for( int iter = length - 1; iter > 0; iter-- )
            {
                int position = rand.nextInt( iter );

                String temp = eightWords[ iter ];

                eightWords[ iter ] = eightWords[ position ];

                eightWords[ position ] = temp;
            }

            return eightWords;
        }
    }

    private void toggleVisibility(int numberOfButtons)
    {
        // TODO change to work off of passed in length saved in ArraySize variable
        switch( numberOfButtons )
        {
            case 4:
                button5.setVisibility(View.INVISIBLE);

                button6.setVisibility(View.INVISIBLE);

                button7.setVisibility(View.INVISIBLE);

                button8.setVisibility(View.INVISIBLE);

                break;

            case 5:
                button5.setVisibility(View.INVISIBLE);

                button7.setVisibility(View.INVISIBLE);

                button8.setVisibility(View.INVISIBLE);

                break;
            case 6:
                button5.setVisibility(View.INVISIBLE);

                button8.setVisibility(View.INVISIBLE);

                break;
            case 7:

                button8.setVisibility(View.INVISIBLE);

                break;
        }
    }

    private void clear()
    {
        result.setText("");

    }

    private void check()
    {
       for( int iter = 0; iter < arraySize; iter++ )
       {
           toggleClickable(buttonArray[ iter ] );
       }

       checkisClicked = false;

      pointsCalculation();
    }

    @Override
    public void onClick(View v)
    {
        Button temp = (Button) v;

        if( result.getText().toString().equals("ENTER A WORD USING BUTTONS!"))
        {
            result.setText("");

            toggleClickable(temp);

            result.append(temp.getText());
        }
        else{

            toggleClickable(temp);

            result.append(temp.getText());
        }
    }

    private void toggleClickable(Button button) {
        {

            if( checkisClicked )
            {
                button.setVisibility(View.VISIBLE);
            }
            else if(  button.getVisibility() == View.VISIBLE ){
                button.setVisibility(View.INVISIBLE);

            }
        }
    }

    private void pointsCalculation()
    {
        String wordToCheck = result.getText().toString();
        pointMult = wordToCheck.length();
        String[] toCheckArr = wordsInFour.split(" ");

        for( String word: toCheckArr )
        {
            if( word.equals(wordToCheck) )
            {
                pointTotal += (5 * wordToCheck.length()) * pointMult;
            }
        }
    }

    private void deductPoints()
    {
        pointTotal -=30;
    }


    public void setMaxProgress(int length)
    {
        if( length == 4 )
        {
            pointsProgress.setMax( wordsInFour.length());
        }
        else if( length == 5 )
        {
            pointsProgress.setMax( wordsInFive.length());
        }
        else if( length == 6 )
        {
            pointsProgress.setMax( wordsInSix.length());
        }
        else if( length == 7 )
        {
            pointsProgress.setMax( wordsInSeven.length());
        }
        else
        {
            pointsProgress.setMax( wordsInEight.length());
        }
    }


}
