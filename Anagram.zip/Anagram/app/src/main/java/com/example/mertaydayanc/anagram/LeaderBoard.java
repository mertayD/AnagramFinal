package com.example.mertaydayanc.anagram;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class LeaderBoard extends AppCompatActivity {

    public static int[] leaderBoard = new int[30];
    public static int size = 0;
    TextView leaderBoardView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_leader_board);
        leaderBoardView = (TextView) findViewById(R.id.tv_leader_board);

        bubbleSort();
        leaderBoardView.append("\n");

        for(int i  = 0; i < size; i++)
        {
            leaderBoardView.append("" + leaderBoard[i] + "\n");
        }

    }

    public void bubbleSort()
    {
        int index1;
        int index2;

        for(index1 = 0; index1 < size; index1++)
        {
            for(index2 = 0; index2 < size -1; index2++)
            {
                if(leaderBoard[index2 + 1] > leaderBoard[index2])
                {
                    swap(index2, index2+1);
                }
            }
        }
    }

    public static void swap(int index1, int index2)
    {
        int hold = leaderBoard[index1];
        leaderBoard[index1] = leaderBoard[index2];
        leaderBoard[index2] = hold;
    }
    public static void updateArr(int point)
    {
        leaderBoard[size] = point;
        size++;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.challengemenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int selectedItem = item.getItemId();
        if(selectedItem == R.id.b_back_main);
        {
            finish();
            return true;
        }
    }
}
