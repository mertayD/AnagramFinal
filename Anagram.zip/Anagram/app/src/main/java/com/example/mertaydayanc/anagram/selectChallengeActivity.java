package com.example.mertaydayanc.anagram;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class selectChallengeActivity extends AppCompatActivity implements View.OnClickListener {

    Button button4;
    Button button5;
    Button button6;
    Button button7;
    Button button8;
    String length;
    ImageView view1;
    ImageView view2;
    ImageView view3;
    ImageView view4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_challenge);

        button4 = findViewById(R.id.challangeButton4);
        button5 = findViewById(R.id.challangeButton5);
        button6 = findViewById(R.id.challangeButton6);
        button7 = findViewById(R.id.challangeButton7);
        button8 = findViewById(R.id.challangeButton8);

        button4.setOnClickListener(this);
        button4.setTextSize(Settings.fontSize);
        button5.setOnClickListener(this);
        button5.setTextSize(Settings.fontSize);
        button6.setOnClickListener(this);
        button6.setTextSize(Settings.fontSize);
        button7.setOnClickListener(this);
        button7.setTextSize(Settings.fontSize);
        button8.setOnClickListener(this);
        button8.setTextSize(Settings.fontSize);


        view1 = (ImageView) findViewById(R.id.iv_hint_1);
        view2 = (ImageView) findViewById(R.id.iv_hint_2);
        view3 = (ImageView) findViewById(R.id.iv_hint_3);
        view4 = (ImageView) findViewById(R.id.iv_hint_4);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.challengemenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int selectedItem = item.getItemId();
        if(selectedItem == R.id.b_back_main);
        {
            finish();
            return true;
        }
    }

    @Override
    public void onClick(View v)
    {
        Button temp = (Button) v;


        Context context = selectChallengeActivity.this;

        Class destinationActivity = game.class;
        Intent startSelectChallengeActivity = new Intent(context, destinationActivity);

        length = temp.getText().toString();

        startSelectChallengeActivity.putExtra("LENGTH", length);

        startActivity(startSelectChallengeActivity);


        }
    }
