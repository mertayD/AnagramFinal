package com.example.mertaydayanc.anagram;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class selectChallengeActivity extends AppCompatActivity implements View.OnClickListener {

    Button b_length4;
    Button b_length5;
    Button b_length6;
    Button b_length7;
    Button b_length8;

    String length;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_challenge);

        b_length4 = findViewById(R.id.challangeButton4);
        b_length5 = findViewById(R.id.challangeButton5);
        b_length6 = findViewById(R.id.challangeButton6);
        b_length7 = findViewById(R.id.challangeButton7);
        b_length8 = findViewById(R.id.challangeButton8);

        b_length4.setOnClickListener(this);
        b_length5.setOnClickListener(this);
        b_length6.setOnClickListener(this);
        b_length7.setOnClickListener(this);
        b_length8.setOnClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.challengemenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int selectedItem = item.getItemId();
        if(selectedItem == R.id.b_back_main);
        {
            finish();
            return true;
        }
    }
    @Override
    public void onClick(View v) {
        Context context = selectChallengeActivity.this;
        Button temp = (Button) v;
        length = temp.getText().toString();
        Class destinationActivity = game.class;
        Intent startSelectChallengeActivity = new Intent(context, destinationActivity);
        startSelectChallengeActivity.putExtra("LENGTH", length);
        startActivity(startSelectChallengeActivity);
    }
}
